import 'package:flutter/material.dart';

class Authors extends StatelessWidget {
  const Authors({super.key});

  @override
  Widget build(BuildContext context) {
    return const Text("Authors");
  }
}